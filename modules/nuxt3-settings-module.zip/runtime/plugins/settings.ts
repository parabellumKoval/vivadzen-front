export default defineNuxtPlugin((nuxtApp) => {
  const state = useState<Record<string, any>>('settings', () => ({}))

  if (process.server) {
    const ev = useRequestEvent()
    // @ts-ignore
    state.value = (ev?.context?.settings as Record<string, any>) || {}
  }

  const getSetting = (key: string, def?: any) => {
    const parts = key.split('.')
    let cur: any = state.value
    for (const p of parts) {
      if (cur && Object.prototype.hasOwnProperty.call(cur, p)) {
        cur = cur[p]
      } else {
        return def
      }
    }
    return cur
  }

  return {
    provide: {
      settings: state,
      getSetting,
    }
  }
})
