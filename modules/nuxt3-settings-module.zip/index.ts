import { defineNuxtModule, addPlugin, createResolver, addServerHandler, addImports, addTemplate } from '@nuxt/kit'

export interface SettingsModuleOptions {
  /**
   * Absolute URL to Laravel settings endpoint
   * e.g. http://localhost:8000/api/settings
   */
  apiUrl: string,
  /**
   * Cache TTL in seconds (default 300 = 5 min)
   */
  ttlSec?: number,
  /**
   * Route for manual cache refresh
   * POST /api/_refresh-settings by default
   */
  refreshRoutePath?: string
}

export default defineNuxtModule<SettingsModuleOptions>({
  meta: {
    name: 'nuxt3-settings-module',
    configKey: 'settingsModule'
  },
  defaults: {
    apiUrl: 'http://localhost:8000/api/settings',
    ttlSec: 300,
    refreshRoutePath: '/api/_refresh-settings'
  },
  setup (options, nuxt) {
    const resolver = createResolver(import.meta.url)

    // Expose module options at runtime via a virtual template
    addTemplate({
      filename: 'nuxt-settings-options.mjs',
      getContents: () => `export default ${JSON.stringify(options)}`,
    })

    // Make a named alias for easy import inside runtime code
    nuxt.options.alias['#nuxt-settings-options'] = resolver.resolve('./.nuxt/nuxt-settings-options.mjs')

    // Register server middleware to inject settings onto event.context
    addServerHandler({
      route: '/',
      handler: resolver.resolve('./runtime/server/middleware/inject-settings'),
    })

    // Register API endpoint for manual refresh (POST)
    addServerHandler({
      route: options.refreshRoutePath || '/api/_refresh-settings',
      handler: resolver.resolve('./runtime/server/api/refresh-settings.post')
    })

    // Register plugin to expose $settings / $getSetting
    addPlugin(resolver.resolve('./runtime/plugins/settings'))

    // Auto-import composable useSettings()
    addImports({
      name: 'useSettings',
      from: resolver.resolve('./runtime/composables/useSettings')
    })
  }
})
